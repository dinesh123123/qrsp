<style type="text/css">
   .error {
    color: red;
}
</style>
<body class="hold-transition skin-blue sidebar-mini">
   <div class="wrapper">
      <?php $this->load->view('admin/navbar') ?>
      <?php $this->load->view('admin/sidebar') ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
         <!-- Content Header (Page header) -->
         <section class="content-header">
            <h1>
               Add Amenities
               <!-- <small> Preview</small> -->
            </h1>
            <ol class="breadcrumb">
               <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
               <li><a href="#">Add Amenities</a></li>
               <li class="active">Amenities</li>
            </ol>
         </section>
         <!-- Main content -->
         <section class="content">
            <div class="row">
               <div class="col-md-6">
                  <?php  if(isset($error)){ echo $error; }
                     echo $this->session->flashdata('success_req'); ?>
                  <!-- general form elements -->
                  <div class="box box-primary">
                     <div class="box-header">
                        <h3 class="box-title">Add Amenities</h3>
                     </div>
                     <!-- /.box-header -->
                     <!-- form start -->
                     <?php if(!empty($this->uri->segment(3)))
                     {
                        ?>
                        <form action="<?php echo base_url()?>Admin/update_amenities/<?= $datas->id; ?>" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="">Name:<span class="text-danger">*</span></label>
                                    <input type="text" name="name" value="<?php echo set_value('name', $datas->name); ?>" class="form-control"/>
                                       <?php echo form_error('name', '<div class="error">', '</div>'); ?>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="">Icon:<span class="text-danger">*</span></label>
                                    <input type="file" name="icon" value="<?php echo set_value('icon'); ?>" class="form-control"/>
                                    <?php echo form_error('icon', '<div class="error">', '</div>'); ?>
                                    <img src="">
                                    <img height="100" src="<?= base_url('assets/uploaded/amenities_images'); ?>/<?php echo $datas->icon; ?>"> 
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="box-footer">
                           <input type="submit" class="btn btn-primary" name="submit" value="Update" />
                        </div>
                     </form>

                        <?php
                     }else{
                        ?>
                        <form action="<?php echo base_url()?>Admin/store_amenities" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="">Name:<span class="text-danger">*</span></label>
                                    <input type="text" name="name" value="<?php echo set_value('name'); ?>" class="form-control"/>
                                       <?php echo form_error('name', '<div class="error">', '</div>'); ?>
                                 </div>
                              </div>
                              <div class="col-md-12">
                                 <div class="form-group">
                                    <label class="">Icon:<span class="text-danger">*</span></label>
                                    <input type="file" name="icon" value="<?php echo set_value('icon'); ?>" class="form-control"/>
                                    <?php echo form_error('icon', '<div class="error">', '</div>'); ?>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="box-footer">
                           <input type="submit" class="btn btn-primary" name="submit" value="Submit" />
                        </div>
                     </form>
                        <?php
                     } ?>
                     
                  </div>
                  <!-- /.box -->
               </div>
               <!-- </div> -->
            </div>
            <!-- Main row -->
         </section>
         <!-- /.content -->
         </aside><!-- /.right-side -->
      </div>
      <?php $this->load->view('admin/footer') ?>
      
      <div class="control-sidebar-bg"></div>
   </div>
</body>
</html>