<aside class="main-sidebar">
   <section class="sidebar">
      <div class="user-panel">
         <div class="pull-left image">
            <img src="<?php echo base_url()?>upload/admin/<?php echo $this->session->userdata('admin_image');?>" class="img-circle" alt="Admin Image">
         </div>
         <div class="pull-left info">
            <p><?php echo $this->session->userdata('admin_name');?></p>
         </div>
      </div>
      <ul class="sidebar-menu" data-widget="tree">
         <!-- <li class="header">MAIN NAVIGATION</li> -->
         <li class="<?php  if($this->uri->segment(1)=='admin' && ($this->uri->segment(2)=='dashboard')) {echo 'active';}?>">
            <a href="<?php echo base_url() ?>admin/dashboard">
               <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            </a>
         </li>
         <li class="<?php  if($this->uri->segment(1)=='admin' && ($this->uri->segment(2)=='restaurants')) {echo 'active';}?>">
            <a href="<?php  echo base_url()?>admin/restaurants">
            <i class="fa fa-cutlery"></i> <span>Restaurants</span>
            </a>
         </li>
      </ul>
   </section>
   <!-- /.sidebar -->
</aside>