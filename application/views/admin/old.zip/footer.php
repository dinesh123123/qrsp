<footer class="main-footer" style="text-align: center;">
    
    <strong>Copyright &copy; 2019 <a href="https://www.logicalsofttech.com">Logical Softtech</a>.</strong> All rights
    reserved.
  </footer>
