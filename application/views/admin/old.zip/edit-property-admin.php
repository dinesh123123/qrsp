<style type="text/css">
   .error {
    color: red;
}
</style>
<body class="hold-transition skin-blue sidebar-mini">
   <div class="wrapper">
      <?php $this->load->view('admin/navbar') ?>
      <?php $this->load->view('admin/sidebar') ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
         <!-- Content Header (Page header) -->
         <section class="content-header">
            <h1>
               Update Property Admin
               <!-- <small> Preview</small> -->
            </h1>
            <ol class="breadcrumb">
               <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
               <li><a href="#">Property Admin Management </a></li>
               <li class="active">Update Property Admin </li>
            </ol>
         </section>
         <!-- Main content -->
         <section class="content">
            <div class="row">
               <div class="col-md-8">
                  <?php  if(isset($error)){ echo $error; }
                     echo $this->session->flashdata('success_req'); ?>
                  <!-- general form elements -->
                  <div class="box box-primary">
                     <div class="box-header">
                        <h3 class="box-title">Update Property Admin </h3>
                     </div>
                  

                     <!-- /.box-header --->
                     <!-- form start -->
                     <form action="<?php echo base_url()?>Admin/update_property_admin/<?= $datas->id; ?>" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">First Name:<span class="text-danger">*</span></label>
                                    <input type="text" name="first_name" value="<?php echo set_value('first_name', $datas->first_name); ?>" class="form-control"/>
                                       <?php echo form_error('first_name', '<div class="error">', '</div>'); ?>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">Last Name:<span class="text-danger">*</span></label>
                                    <input type="text" name="last_name" value="<?php echo set_value('last_name', $datas->last_name); ?>" class="form-control"/>
                                    <?php echo form_error('last_name', '<div class="error">', '</div>'); ?>
                                 </div>
                              </div>
                           </div>

                           <div class="row">
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">Contact Number:<span class="text-danger">*</span></label>
                                    <input type="text" name="contact_number" value="<?php echo set_value('contact_number', $datas->contact_number); ?>" class="form-control"/>
                                    <?php echo form_error('contact_number', '<div class="error">', '</div>'); ?>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">Email:<span class="text-danger">*</span></label>
                                    <input type="text" name="email" value="<?php echo set_value('email', $datas->email); ?>" class="form-control"/>
                                    <?php echo form_error('email', '<div class="error">', '</div>'); ?>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">House Number:<span class="text-danger"></span></label>
                                    <input type="text" name="house_number" value="<?php echo set_value('house_number', $datas->house_number); ?>" class="form-control"/>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">Colony:<span class="text-danger"></span></label>
                                    <input type="text" name="colony" value="<?php echo set_value('colony', $datas->colony); ?>" class="form-control"/>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">City:<span class="text-danger"></span></label>
                                    <input type="text" name="city" value="<?php echo set_value('city', $datas->city); ?>" class="form-control"/>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">State:<span class="text-danger"></span></label>
                                    <input type="text" name="state" value="<?php echo set_value('state', $datas->state); ?>" class="form-control"/>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                               <!-- <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">Country :<span class="text-danger"></span></label>
                                    <input type="text" name="last_name" class="form-control"/>
                                 </div>
                              </div> -->
                              <div class="col-md-6">
                                 <div class="form-group">
                                    <label class="">Zip Code:<span class="text-danger"></span></label>
                                    <input type="text" name="zip_code" value="<?php echo set_value('zip_code', $datas->zip_code); ?>" class="form-control"/>
                                 </div>
                              </div>
                           </div>
                              <h4 class="box-title">Login Detail </h4>
                           <br>
                           <div class="row">
                               <div class="col-md-6">
                                <div class="form-group">
                                    <label> Username :<span class="text-danger">*</span></label>
                                    <input type="text" name="user_name" value="<?php echo set_value('user_name', $datas->user_name); ?>" class="form-control"/>
                                    <?php echo form_error('user_name', '<div class="error">', '</div>'); ?>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                <div class="form-group">
                                    <label class="">Password:<span class="text-danger">*</span></label>
                                    <input type="text" name="password" value="<?php echo set_value('password', $datas->password); ?>" class="form-control"/>
                                    <?php echo form_error('password', '<div class="error">', '</div>'); ?>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="box-footer">
                           <input type="submit" class="btn btn-primary" name="submit" value="Submit" />
                        </div>
                     </form>

                      
                  </div>
                  <!-- /.box -->
               </div>
               <!-- </div> -->
            </div>
            <!-- Main row -->
         </section>
         <!-- /.content -->
         </aside><!-- /.right-side -->
      </div>
      <!-- /.content-wrapper -->
      <?php $this->load->view('admin/footer') ?>
      <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
   </div>
   <!-- ./wrapper -->
  <!--  <script type="text/javascript">
      $(function() { 
        $('#item_pic').hide(); 
       
      });
      
        function imgchange(f) 
        {
            var filePath = $('#file').val();
            var reader = new FileReader();
            reader.onload = function (e) 
            {
              $('#item_pic').show(); 
                var target=e.target.result;
                var newimg=$('#update_img').attr('src',target);
            };
            reader.readAsDataURL(f.files[0]);  
      
        };
   </script> -->
</body>
</html>