<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php $this->load->view('admin/navbar') ?>
  <?php $this->load->view('admin/sidebar') ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Amenities
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('Admin/dashboard');?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Amenities Management</li>
        <li class="active">Amenities</li>

      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
        <?php  if(isset($error)){ echo $error; }
        echo $this->session->flashdata('success_req'); ?>
          <div class="box box-primary">
            <div class="box-header">
              <h3 class="box-title">Amenities </h3>
              <a href="<?php echo base_url()?>admin/add_amenities" class="btn btn-info btn-sm pull-right ">Add Amenities</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="table-responsive" style="overflow-x:auto;">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>S.no</th>
                  <th>Name</th>
                  <th>Icon</th>
                  <th>Action</th> 
                </tr>
                </thead>
                <tbody>
              <?php 
                foreach ($amenities as $key => $value)
                { ?>
                <tr>
                  <td><?php echo $key+1;?></td>
                  <td><?php echo $value['name']?></td>
                  <td><img height="100" width="80" src="<?= base_url('assets/uploaded/amenities_images'); ?>/<?php echo $value['icon']; ?>">  </td>
                  <td class="text-center">
                  <?php echo anchor('admin/edit_amenities/'.$value['id'], '<i class="fa fa-edit"></i>', array("class"=>"btn btn-success")); ?>  
                  <?php echo anchor('admin/delete_amenities/'.$value['id'], '<i class="fa fa-times"></i>', array("class"=>"btn btn-danger", "onclick"=>"return confirm('Are you sure delete?')")); ?>
                  </td>
                </tr>
                <?php }?>
                </tbody>
              
              </table>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
          
        </div>
        <!-- /.col -->
      </div>

      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
    <?php $this->load->view('admin/footer') ?>
    <div class="control-sidebar-bg"></div>
</div>
</body>
</html>
